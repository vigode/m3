package bdd;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class success extends PathPages2{
		
	public success() {
		System.out.println("**");
		PageFactory.initElements(Browser.driver, this);
	}
	@FindBy(how=How.ID,id="fname")
	private WebElement fname;
	
	public String getFname() {
		return fname.getText();
	} 

	@FindBy(how=How.ID,id="lname")
	private WebElement lname;
	
	public String getLname() {
		return lname.getText();
	} 
	@FindBy(how=How.ID,id="fname1")
	private WebElement fname1;

	@FindBy(how=How.ID,id="lname1")
	private WebElement lname1;

	public String getFname1() {
		return fname1.getText();
	}

	public String getLname1() {
		return lname1.getText();
	}
	
	
	
	

}

package bdd;

public class PathPages {
	static String pwd = System.getProperty("user.dir");
	static String url = pwd + "\\src\\main\\webapp\\LoanApplicationPage.html";
	static String title = "Loan Application Page";
	
	public void goTo() {
		
		Browser.goTo(url);
	}

	public boolean isAt() {
		return Browser.title().equals(title);
	}
}

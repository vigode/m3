package bdd;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.openqa.selenium.WebElement;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Defs {

	static int i;
	LoanApplication loanapp2 = new LoanApplication();
	success sp = new success();
	String first, last;

	@Given("^we are on html page$")
	public void we_are_on_html_page() throws Exception {
		// Write code here that turns the phrase above into concrete actions
//    throw new PendingException();
		loanapp2.goTo();
		assertTrue(loanapp2.isAt());

	}

	@Given("^we entered \"([^\"]*)\" in firstname box:$")
	public void we_entered_in_firstname_box(String arg1) throws Exception {
		// Write code here that turns the phrase above into concrete actions
//    throw new PendingException();
		first = arg1;
		WebElement abc = loanapp2.getFirstName();
		abc.sendKeys(arg1);
	}

	@Given("^we entered \"([^\"]*)\" in lastname box:$")
	public void we_entered_in_lastname_box(String arg1) throws Exception {
		// Write code here that turns the phrase above into concrete actions
//    throw new PendingException();
		last = arg1;
		WebElement abc = loanapp2.getLastName();
		abc.sendKeys(arg1);

	}

	@Given("^we checked the tnc checkbox$")
	public void we_checked_the_tnc_checkbox() throws Exception {
		// Write code here that turns the phrase above into concrete actions
//    throw new PendingException();
		WebElement abc = loanapp2.getTnc();
		abc.click();
	}

	@When("^we clicked on submit$")
	public void we_clicked_on_submit() throws Exception {
		// Write code here that turns the phrase above into concrete actions
//    throw new PendingException();
		WebElement abc = loanapp2.getForm();
		abc.submit();

	}

	@Then("^Success page should be displayed\\.$")
	public void success_page_should_be_displayed() throws Exception {
		// Write code here that turns the phrase above into concrete actions
//    throw new PendingException();

		sp.goTo();

		System.out.println("value of i is "+i);
		if(i==0)
		{
			assertEquals(first, sp.getFname());
			assertEquals(last, sp.getLname());
			System.out.println("in i equals 0");
		}
		if(i==1)
		{

			System.out.println("in i equals 1");
			System.out.println(sp.getFname1()+"____getters");
			System.out.println(first);
			assertEquals(first, sp.getFname1());
			
			assertEquals(last, sp.getLname1());
		}
		
		i=i+1;
		System.out.println("******"+i+"********");
	}
}

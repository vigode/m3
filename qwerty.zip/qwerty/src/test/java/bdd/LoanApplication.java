package bdd;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class LoanApplication extends PathPages{

	public LoanApplication() {
		System.out.println("--");
		PageFactory.initElements(Browser.driver, this);
	}
	@FindBy(how=How.ID,id="firstName")
	private WebElement firstName; 
	
	@FindBy(how=How.ID,id="lastName")
	private WebElement LastName; 
	
	@FindBy(how=How.ID,id="form")
	private WebElement form;
	
	@FindBy(how=How.NAME,name="TermsAcceptance")
	private WebElement tnc;

	public WebElement getFirstName() {
		System.out.println("in first name...");
		System.out.println(firstName+"value");
		return firstName;
	}

	public void setFirstName(WebElement firstName) {
		this.firstName = firstName;
	}

	public WebElement getLastName() {
		return LastName;
	}

	public void setLastName(WebElement lastName) {
		LastName = lastName;
	}

	public WebElement getForm() {
		return form;
	}

	public void setForm(WebElement form) {
		this.form = form;
	}

	public WebElement getTnc() {
		return tnc;
	}

	public void setTnc(WebElement tnc) {
		this.tnc = tnc;
	}
	
	
}

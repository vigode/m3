package bdd;

public class PathPages2 {
	
	static String pwd = System.getProperty("user.dir");
	static String url = pwd + "\\src\\main\\webapp\\success.html";
	static String title = "success";
	
	public void goTo() {
		
		Browser.goTo(url);
	}

	public boolean isAt() {
		return Browser.title().equals(title);
	}
}

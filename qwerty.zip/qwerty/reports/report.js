$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/test/resources/details.feature");
formatter.feature({
  "name": "infoForm",
  "description": "\tIn order to login\n\tAs a idiot\n\tI want to feed first name and last name in form",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "name": "Feed the details",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "we are on html page",
  "keyword": "Given "
});
formatter.step({
  "name": "we entered \"\u003cfirstName\u003e\" in firstname box:",
  "keyword": "And "
});
formatter.step({
  "name": "we entered \"\u003clastName\u003e\" in lastname box:",
  "keyword": "And "
});
formatter.step({
  "name": "we checked the tnc checkbox",
  "keyword": "And "
});
formatter.step({
  "name": "we clicked on submit",
  "keyword": "When "
});
formatter.step({
  "name": "Success page should be displayed.",
  "keyword": "Then "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Examples",
  "rows": [
    {
      "cells": [
        "firstName",
        "lastName"
      ]
    },
    {
      "cells": [
        "rahul",
        "chandra"
      ]
    },
    {
      "cells": [
        "benjamin",
        "haokip"
      ]
    }
  ]
});
formatter.scenario({
  "name": "Feed the details",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "we are on html page",
  "keyword": "Given "
});
formatter.match({
  "location": "Defs.we_are_on_html_page()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "we entered \"rahul\" in firstname box:",
  "keyword": "And "
});
formatter.match({
  "location": "Defs.we_entered_in_firstname_box(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "we entered \"chandra\" in lastname box:",
  "keyword": "And "
});
formatter.match({
  "location": "Defs.we_entered_in_lastname_box(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "we checked the tnc checkbox",
  "keyword": "And "
});
formatter.match({
  "location": "Defs.we_checked_the_tnc_checkbox()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "we clicked on submit",
  "keyword": "When "
});
formatter.match({
  "location": "Defs.we_clicked_on_submit()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Success page should be displayed.",
  "keyword": "Then "
});
formatter.match({
  "location": "Defs.success_page_should_be_displayed()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Feed the details",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "we are on html page",
  "keyword": "Given "
});
formatter.match({
  "location": "Defs.we_are_on_html_page()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "we entered \"benjamin\" in firstname box:",
  "keyword": "And "
});
formatter.match({
  "location": "Defs.we_entered_in_firstname_box(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "we entered \"haokip\" in lastname box:",
  "keyword": "And "
});
formatter.match({
  "location": "Defs.we_entered_in_lastname_box(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "we checked the tnc checkbox",
  "keyword": "And "
});
formatter.match({
  "location": "Defs.we_checked_the_tnc_checkbox()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "we clicked on submit",
  "keyword": "When "
});
formatter.match({
  "location": "Defs.we_clicked_on_submit()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Success page should be displayed.",
  "keyword": "Then "
});
formatter.match({
  "location": "Defs.success_page_should_be_displayed()"
});
formatter.result({
  "status": "passed"
});
});